class HelloWorldController < ApplicationController
  def index
  end
end
